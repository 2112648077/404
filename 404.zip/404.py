import time

print("9")
time.sleep(1)
print("8")
time.sleep(1)
print("7")
time.sleep(1)
print("6")
time.sleep(6)
print("Error code6X6")
time.sleep(6)
print("6.6.2025,18:18:18")
